import pygame as pyg
from expansion import *
from random import randint

pyg.init()

exph=widghtex()
expw=highex()

ypl=exph-195-50
xpl=expw//2-100//2

ykaktus = ypl

isJump = False
jumpCount = 10
kaktusx = []
end = False
font1 = pyg.font.Font(None, 100)
font2 = pyg.font.Font(None, 60)
score = 0
kaktus=pyg.image.load("pixels.png")
atj=pyg.image.load("dinojump.png")
dinend=pyg.image.load("dinokaktus.png")
bg=pyg.image.load("bg.png")
ls=pyg.image.load("sl.png")
rs=pyg.image.load("sp.png")
rig=randint(9,12)
uper=0
go=False

def arting(xpl,ypl,rig,uper):
    

    rig=randint(0,50)
    if isJump:
        window.blit(atj,(xpl,ypl))
    elif not(isJump) and not (end):
        if go:
            window.blit(rs,(xpl,ypl))
        if not(go):
            window.blit(ls,(xpl,ypl))
        
        if rig==10:

            uper=True
        else:
            uper=False
    if end:
        window.blit(dinend,(xpl,ypl))

    window.blit(kaktus,(kaktusx[0],ykaktus))
    

gameRun = True
pik=True
window=pyg.display.set_mode((expw,exph))
pyg.display.set_caption("DragoZavr")


while len(kaktusx)<1:
    kaktusx.append(1920)
   


while gameRun:
    window.blit(bg,(0,0))
    uper+=1
    if uper >=2 and uper <=9:
        go=True
        print("laa")
    elif uper >=10:
        go=False
        uper=-10
        print("go")
    

    if not(end):
        score += 0.3

    txt0="Score: "+str(round(score))
    text0 = font2.render(txt0, 1, (0, 0, 0))
    place0 = text0.get_rect(center=(expw-200, 50))
    window.blit(text0, place0)

    if end:

        txt1="GAME OVER"
        text1 = font1.render(txt1, 1, (255, 0, 0))
        place1 = text1.get_rect(center=(expw//2, exph//3))
        window.blit(text1, place1)

        txt2="Click on screen for restart game"
        text2 = font2.render(txt2, 1, (255, 0, 0))
        place2 = text1.get_rect(center=(expw//2-100, exph//2))
        window.blit(text2, place2)
        mouse = pyg.mouse.get_pos()
        kaktusx[0]=expw
  
        button1 = pyg.Rect(expw//2-50,exph//2,100,50)
        pyg.display.flip()
        
        
        press1 = pyg.mouse.get_pressed(button1)
        if press1[0]==1 or press1[1]==1 or keys[pyg.K_SPACE]:
            end=False
            score=0
            kaktusx[0]=1920

    if xpl<=kaktusx[0]+50 and xpl+50>=kaktusx[0] and ypl<=ykaktus+75 and ypl>=ykaktus:
        end=True

    if not(end):
        kaktusx[0]-=10
    if kaktusx[0]<=-50:
        kaktusx[0]=1920


    arting(xpl, ypl, rig, uper)
    pyg.display.update()

    for event in pyg.event.get():
        if event.type == pyg.QUIT:
            gameRun=False
    
    keys = pyg.key.get_pressed()
    if not (isJump):
        if (keys[pyg.K_UP] or keys[pyg.K_w] or keys[pyg.K_SPACE] and not(end)):
            print("It is jump!")
            isJump = True
    else:

        if jumpCount >= -10:
            if jumpCount<0:
                ypl += (jumpCount**2) //2
            else:
                ypl -= (jumpCount**2) //2
            jumpCount -= 1
        else:
            isJump = False
            jumpCount = 10